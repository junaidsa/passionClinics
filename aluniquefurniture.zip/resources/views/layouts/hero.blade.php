

    <!-- Hero Section Start -->
    <div class="hero hero-bg-image hero-video bg-section dark-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <!-- Hero Content Start -->
                    <div class="hero-content">
                        <!-- Section Title Start -->
                        <div class="section-title">
                            <h3 class="wow fadeInUp">WELCOME TO PASSION CLINICS</h3>
                            <h1 class="text-anime-style-3" data-cursor="-opaque">{{$sett->title}}</h1>
                            <p class="wow fadeInUp" data-wow-delay="0.2s">{{$sett->description}}</p>
                        </div>
                        <div class="hero-body wow fadeInUp" data-wow-delay="0.4s">
                            <!-- Hero Button Start -->
                            <div class="hero-btn">
                                <a href="#" class="btn-default btn-highlighted">Book an Appointment</a>
                            </div>
                            <div class="video-play-button">
                                <p>Watch Video</p>
                                <a href="{{$sett->youtube_url}}" class="popup-video" data-cursor-text="Play">
                                    <i class="fa-solid fa-play"></i>
                                </a>
                            </div>
                            <!-- Video Play Button End -->
                        </div>
                        <!-- Hero Content Body End -->
                    </div>
                    <!-- Hero Content End -->
                </div>
            </div>
        </div>
    </div>
    <!-- Hero Section End -->
