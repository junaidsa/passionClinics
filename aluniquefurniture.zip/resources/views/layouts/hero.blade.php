

    <!-- Hero Section Start -->
    <div class="hero hero-bg-image hero-video bg-section dark-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <!-- Hero Content Start -->
                    <div class="hero-content">
                        <!-- Section Title Start -->
                        <div class="section-title">
                            <h3 class="wow fadeInUp">@lang('app.welcome_to_passion_clinic')</h3>
                            <h1 data-cursor="-opaque">{{ App::isLocale('ar') ? $sett->title_ar : $sett->title }}</h1>
                            <p class="wow fadeInUp" data-wow-delay="0.2s" >{{ App::isLocale('ar') ? $sett->description_ar : $sett->description }}</p>
                        </div>
                        <div class="hero-body wow fadeInUp" data-wow-delay="0.4s">
                            <!-- Hero Button Start -->
                            <div class="hero-btn">
                                <a href="#" class="btn-default btn-highlighted">@lang('app.book_an_appointment')</a>
                            </div>
                            <!-- Video Play Button End -->
                        </div>
                        <!-- Hero Content Body End -->
                    </div>
                    <!-- Hero Content End -->
                </div>
            </div>
        </div>
    </div>
    <!-- Hero Section End -->
