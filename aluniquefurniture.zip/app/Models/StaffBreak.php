<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class StaffBreak extends Model
{
    //
    protected $guarded = [];
}
